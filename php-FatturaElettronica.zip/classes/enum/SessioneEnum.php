<?php

class SessioneEnum {
    
    const PREFIX = "php-fattelett-";
    const SESSIONID = PREFIX."id";
    const TIMEOUT = PREFIX."timeout";
    const IDUTENTE = PREFIX."idutente";
    const USERNAME = PREFIX."username";
    
}