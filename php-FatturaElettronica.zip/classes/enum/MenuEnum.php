<?php



class MenuEnum {
    
    const Profilo = 'profilo/profiloDetail';
    
    static $menuList = array(
        'profilo/profiloDetail' => 'Profilo'
    );
    
    
}

?>