<?php



class MenuAdminEnum {
    
    const Utenti = 'adminUtenti/utentiList';
    
    static $menuList = array(
        'adminUtenti/utentiList' => 'Utenti'
    );
    
    
}

?>