<?php
/**
 * 
 * 
 * @author FrancescoCeliento
 */
class ParametroDO extends BaseDO {
    public $chiave;
    public $valore;
    public $visibile;
}