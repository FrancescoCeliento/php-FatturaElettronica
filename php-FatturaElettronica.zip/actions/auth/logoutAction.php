<?php

$sessione->logout();

?>