<h1>Ciao <?=$sessione->nome?></h1>
<p>Compila rapidamente e con facilit&agrave; le tue fatture elettroniche.</p>