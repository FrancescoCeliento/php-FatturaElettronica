# php-FattureElettroniche
Progetto opensource scritto in PHP per la compilazione semplificata della fattura elettronica
