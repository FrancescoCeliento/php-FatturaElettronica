<footer>
    <p>v<?php include('version.txt');?> (<a href="https://github.com/FrancescoCeliento/php-FatturaElettronica/blob/dev/changelog.txt" target="_blank">changelog</a>) &#x2022; Supportami su <a href="https://ko-fi.com/francescoceliento" target="_blank">Ko-Fi</a></p>
</footer>

</body>